# main.py
import os
from update import UpdateManager

# Define the project details
PROJECT_NAME = "test"
CURRENT_VERSION = "1.0.1"
UPDATE_URL = "https://garrettstrange.com//version/version.json"
APP_DIR = os.path.dirname(os.path.abspath(__file__))

def run_application():
    print(f"Running {PROJECT_NAME} version {CURRENT_VERSION}...")
    # Your main application logic here
    input("Press Enter to exit the app...")

def main():
    # Initialize the Update Manager
    update_manager = UpdateManager(
        project_name=PROJECT_NAME,
        current_version=CURRENT_VERSION,
        update_url=UPDATE_URL,
        app_dir=APP_DIR
    )

    # Check for updates
    update_manager.check_for_update()

    # If no update is found, continue running the application
    run_application()

if __name__ == "__main__":
    main()
# update_manager.py