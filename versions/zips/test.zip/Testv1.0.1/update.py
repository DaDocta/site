import requests
import zipfile
import os
import subprocess
import tkinter as tk
from tkinter import messagebox

class UpdateManager:
    def __init__(self, project_name, current_version, update_url, app_dir):
        self.project_name = project_name
        self.current_version = current_version
        self.update_url = update_url
        self.app_dir = app_dir

    def check_for_update(self):
        try:
            response = requests.get(self.update_url, timeout=5)  # Set a timeout for the request
            version_data = response.json()

            # Check if the app exists in the versions.json file
            if self.project_name in version_data:
                app_data = version_data[self.project_name]
                latest_version = app_data["version"]
                zip_url = app_data["zip_url"]

                if latest_version != self.current_version:
                    self.prompt_update(latest_version, zip_url)
                else:
                    print(f"{self.project_name} is up to date (version {self.current_version}).")
            else:
                print(f"No update information found for {self.project_name} in {self.update_url}.")

        except requests.exceptions.ConnectionError:
            print(f"Unable to check for updates. No internet connection.")
        except requests.exceptions.Timeout:
            print(f"Update check timed out. Please try again later.")
        except Exception as e:
            print(f"Failed to check for updates: {e}")

    def prompt_update(self, new_version, download_url):
        root = tk.Tk()
        root.withdraw()  # Hide main window
        result = messagebox.askyesno(f"Update Available for {self.project_name}",
                                     f"Version {new_version} is available. Would you like to download and install it?")
        if result:
            self.download_and_install_update(new_version, download_url)
        root.destroy()

    def download_and_install_update(self, new_version, download_url):
        try:
            # Download the update
            response = requests.get(download_url, stream=True)
            update_zip_path = os.path.join(self.app_dir, "update.zip")
            
            with open(update_zip_path, "wb") as update_file:
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        update_file.write(chunk)
            
            # Extract the update
            with zipfile.ZipFile(update_zip_path, "r") as zip_ref:
                zip_ref.extractall(self.app_dir)
            
            os.remove(update_zip_path)
            
            # Update the version file or perform any necessary post-update tasks
            print(f"{self.project_name} updated to version {new_version}.")
            
            # Optionally, re-launch the updated project if necessary
            # subprocess.Popen([os.path.join(self.app_dir, f"{self.project_name}.exe")])  # Adjust as necessary
            exit(0)
        
        except Exception as e:
            print(f"Failed to download and install update for {self.project_name}: {e}")
